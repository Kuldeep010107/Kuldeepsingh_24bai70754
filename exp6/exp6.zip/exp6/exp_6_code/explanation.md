# Experiment 2.1.2: Global Exception Handling & Structured Logging

**Aim:** Build a robust and observable backend using centralised exception handling, request logging and correlation IDs.

---

## 1. Global Exception Handling (`@ControllerAdvice`)
**Problem:** try/catch in every controller = duplicated code and inconsistent error messages.

**Solution:** `exception/GlobalExceptionHandler.java` is annotated with `@RestControllerAdvice` (= `@ControllerAdvice` + `@ResponseBody`). Each `@ExceptionHandler` method converts one type of exception into a standard JSON `ErrorResponse`.

| Exception | HTTP status |
|---|---|
| `ResourceNotFoundException` (custom) | 404 |
| `InvalidRequestException` (custom) | 400 |
| `MethodArgumentNotValidException` (`@Valid` failed) | 400 + field details |
| `MethodArgumentTypeMismatchException` (`/tasks/abc`) | 400 |
| `HttpMessageNotReadableException` (bad JSON) | 400 |
| `HttpRequestMethodNotSupportedException` | 405 |
| `NoResourceFoundException` (unknown URL) | 404 |
| `Exception` (anything else) | 500 (safe generic message) |

## 2. Custom Exceptions
`ResourceNotFoundException` and `InvalidRequestException` carry business meaning. The service throws them (e.g. `toggleTask` on a missing id) and the advice decides the HTTP status.

## 3. Standard Error Structure
`exception/ErrorResponse.java` (a Java record):
```json
{
  "timestamp": "2026-10-05T10:15:30.123",
  "status": 404,
  "error": "Not Found",
  "message": "Task not found with id: 999",
  "path": "/api/tasks/999",
  "correlationId": "3f1c9a52-...-b7e1",
  "details": null
}
```

## 4. Filter vs Interceptor
| | Filter (`CorrelationIdFilter`) | Interceptor (`RequestLoggingInterceptor`) |
|---|---|---|
| Belongs to | Servlet API | Spring MVC |
| Runs | Before Spring MVC (outermost) | Around the controller method |
| Used here for | Create/read correlation ID, put in MDC | Log request, status code, time taken |

## 5. Correlation ID with MDC
- `CorrelationIdFilter` reads the `X-Correlation-Id` header (or generates a UUID), stores it in **MDC** (Mapped Diagnostic Context, a thread-local map), and returns it in the response header.
- The log pattern `%X{correlationId}` prints it on **every** log line of that request.
- The ID is also inside `ErrorResponse`, so a user can quote it and a developer can grep the logs for the whole request lifecycle.
- `MDC.remove()` runs in `finally` because server threads are reused.

## 6. Logging (SLF4J + Logback)
Configured in `application.properties`:
```
logging.pattern.console=%d{HH:mm:ss.SSS} %-5level [%X{correlationId:-no-id}] %logger{30} - %msg%n
logging.file.name=logs/app.log
```
Levels: `INFO` normal flow, `WARN` client errors (4xx), `ERROR` server errors (5xx, with stack trace).

Sample log for one request:
```
10:15:30.101 INFO  [3f1c9a52-...] c.e.b.f.RequestLoggingInterceptor - --> GET /api/tasks/999
10:15:30.108 WARN  [3f1c9a52-...] c.e.b.e.GlobalExceptionHandler - Resource not found: Task not found with id: 999
10:15:30.110 WARN  [3f1c9a52-...] c.e.b.f.RequestLoggingInterceptor - <-- GET /api/tasks/999 | status=404 | 9 ms
```

## 7. New / Changed Files
```
backend/src/main/java/com/example/backend/
├── exception/
│   ├── GlobalExceptionHandler.java      # @RestControllerAdvice
│   ├── ResourceNotFoundException.java   # custom (404)
│   ├── InvalidRequestException.java     # custom (400)
│   ├── ErrorResponse.java               # standard error body
│   └── CorrelationIdFilterKeys.java     # header/MDC constants
├── filter/
│   ├── CorrelationIdFilter.java         # servlet filter + MDC
│   └── RequestLoggingInterceptor.java   # request/response logging
├── config/WebConfig.java                # registers the interceptor
├── service/TaskService.java             # throws custom exceptions, logs
├── entity/Task.java                     # @NotBlank / @Size validation
└── StudentTaskManagerApplication.java   # @Valid, GET /{id}, /demo/error
```
Frontend: `App.jsx` shows the backend's error message + correlation ID in a red banner.

*(The earlier Experiment 6 features – pagination, JOIN FETCH, caching, native SQL, H2 – are all still included.)*

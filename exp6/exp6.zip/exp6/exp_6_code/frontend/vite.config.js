import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // In dev mode, forward API calls to the Spring Boot backend
    proxy: {
      '/api': 'http://localhost:8080',
    },
  },
})

package com.example.backend.filter;

import com.example.backend.exception.CorrelationIdFilterKeys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * SERVLET FILTER - runs before everything else.
 * Gives every request a correlation ID and stores it in the MDC so every log line
 * written while handling this request automatically contains it.
 *
 * If the client already sent X-Correlation-Id we reuse it, otherwise we generate one.
 * The ID is also returned in the response header.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String correlationId = request.getHeader(CorrelationIdFilterKeys.HEADER);
        if (correlationId == null || correlationId.isBlank()) {
            correlationId = UUID.randomUUID().toString();
        }

        MDC.put(CorrelationIdFilterKeys.MDC_KEY, correlationId);
        response.setHeader(CorrelationIdFilterKeys.HEADER, correlationId);

        try {
            filterChain.doFilter(request, response);
        } finally {
            // IMPORTANT: server threads are reused, so always clean up
            MDC.remove(CorrelationIdFilterKeys.MDC_KEY);
        }
    }
}

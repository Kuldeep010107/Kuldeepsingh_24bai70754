package com.example.backend.service;

import com.example.backend.entity.Task;
import com.example.backend.exception.ResourceNotFoundException;
import com.example.backend.repository.TaskRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private static final Logger log = LoggerFactory.getLogger(TaskService.class);

    private final TaskRepository taskRepository;

    @Autowired
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    // Pagination and Sorting example
    public Page<Task> getTasksPaginated(Pageable pageable) {
        log.debug("Fetching tasks page={} size={}", pageable.getPageNumber(), pageable.getPageSize());
        return taskRepository.findAll(pageable);
    }

    // Throws ResourceNotFoundException (-> 404) if the task does not exist
    public Task getTaskById(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task", id));
    }

    // Caching example: Cache the result of fetching all tasks with comments
    @Cacheable("tasks")
    public List<Task> getAllTasksWithComments() {
        log.info("Cache MISS - loading tasks with comments from the database");
        // Simulated delay to prove caching works
        try {
            Thread.sleep(1500); // 1.5 second delay
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return taskRepository.findAllWithComments();
    }

    // Native query example
    public List<Task> getTop5Tasks() {
        return taskRepository.findTop5TasksNative();
    }

    // Evict cache when a new task is added
    @CacheEvict(value = "tasks", allEntries = true)
    public Task addTask(Task task) {
        Task saved = taskRepository.save(task);
        log.info("Task created with id={}", saved.getId());
        return saved;
    }

    // Evict cache when a task is deleted
    @CacheEvict(value = "tasks", allEntries = true)
    public void deleteTask(Long id) {
        if (!taskRepository.existsById(id)) {
            throw new ResourceNotFoundException("Task", id);
        }
        taskRepository.deleteById(id);
        log.info("Task deleted with id={}", id);
    }

    // Evict cache when a task is updated
    @CacheEvict(value = "tasks", allEntries = true)
    public Task toggleTask(Long id) {
        Task task = getTaskById(id);
        task.setCompleted(!task.isCompleted());
        log.info("Task id={} toggled to completed={}", id, task.isCompleted());
        return taskRepository.save(task);
    }
}

package com.example.backend.exception;

/**
 * Custom exception thrown when the client sends a request that violates a business rule.
 * Mapped to HTTP 400 by GlobalExceptionHandler.
 */
public class InvalidRequestException extends RuntimeException {

    public InvalidRequestException(String message) {
        super(message);
    }
}

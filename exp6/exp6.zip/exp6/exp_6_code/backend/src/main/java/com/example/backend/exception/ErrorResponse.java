package com.example.backend.exception;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Standard error structure returned by EVERY failing API call.
 * One structure makes the API predictable for clients (React, Postman, mobile apps...).
 */
public record ErrorResponse(
        LocalDateTime timestamp,
        int status,
        String error,
        String message,
        String path,
        String correlationId,   // same ID that appears in the server logs -> easy debugging
        List<String> details    // optional: field-level validation messages
) {
}

package com.example.backend.exception;

/** Shared constants for the correlation ID (used by the filter, the handler and the log pattern). */
public final class CorrelationIdFilterKeys {
    public static final String HEADER = "X-Correlation-Id";
    public static final String MDC_KEY = "correlationId";

    private CorrelationIdFilterKeys() {
    }
}

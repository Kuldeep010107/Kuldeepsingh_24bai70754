package com.example.backend.filter;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * SPRING MVC INTERCEPTOR - runs around the controller method.
 *  preHandle        -> before the controller (log the incoming request, start the timer)
 *  afterCompletion  -> after the response    (log status code + time taken)
 */
public class RequestLoggingInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingInterceptor.class);
    private static final String START_TIME = "requestStartTime";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        request.setAttribute(START_TIME, System.currentTimeMillis());
        log.info("--> {} {}{}", request.getMethod(), request.getRequestURI(),
                request.getQueryString() != null ? "?" + request.getQueryString() : "");
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) {
        Object start = request.getAttribute(START_TIME);
        long duration = start == null ? -1 : System.currentTimeMillis() - (Long) start;
        int status = response.getStatus();

        if (status >= 500) {
            log.error("<-- {} {} | status={} | {} ms", request.getMethod(), request.getRequestURI(), status, duration);
        } else if (status >= 400) {
            log.warn("<-- {} {} | status={} | {} ms", request.getMethod(), request.getRequestURI(), status, duration);
        } else {
            log.info("<-- {} {} | status={} | {} ms", request.getMethod(), request.getRequestURI(), status, duration);
        }
    }
}

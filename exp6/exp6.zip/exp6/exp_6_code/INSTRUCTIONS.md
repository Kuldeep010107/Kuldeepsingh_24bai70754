# Student Task Manager – Experiment 2.1.2 (Frontend + Backend combined)

## Run (one command)
```bash
cd exp_6_code/backend
mvn spring-boot:run
```
Open **http://localhost:8080** (React UI is served by Spring Boot). Logs also go to `backend/logs/app.log`.

H2 console: http://localhost:8080/h2-console (JDBC URL `jdbc:h2:mem:testdb`, user `sa`, empty password)

## Test in Postman / browser
| # | Request | Expected |
|---|---|---|
| 1 | `GET /api/tasks?page=0&size=5&sort=id,desc` | 200, paginated tasks |
| 2 | `GET /api/tasks/999` | **404** `Task not found with id: 999` |
| 3 | `GET /api/tasks/abc` | **400** invalid value 'abc' |
| 4 | `POST /api/tasks` body `{"title":"","completed":false}` | **400** Validation failed + `details` |
| 5 | `POST /api/tasks` body `{bad json` | **400** Malformed JSON |
| 6 | `PUT /api/tasks/999/toggle` | **404** |
| 7 | `DELETE /api/tasks/999` | **404** |
| 8 | `POST /api/tasks/1` | **405** Method not allowed |
| 9 | `GET /api/tasks/demo/error` | **500** generic message (stack trace only in logs) |
| 10 | Any request with header `X-Correlation-Id: my-test-123` | same ID in response header, error body and every log line |

**What to observe:** every response has an `X-Correlation-Id` header; copy it and search `logs/app.log` – you will see the complete life of that request.

## Rebuilding the frontend (only if you edit it)
```bash
cd exp_6_code/frontend
npm install
npm run build
rm -rf ../backend/src/main/resources/static/*
cp -r dist/* ../backend/src/main/resources/static/
```
For live reload: run `npm run dev` (Vite proxies `/api` to port 8080).
